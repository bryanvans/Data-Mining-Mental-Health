from flask import Flask, request, render_template
import numpy as np
import joblib

app = Flask(__name__)

model = joblib.load('model_logreg.pkl')
scaler = joblib.load('scaler.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        name = request.form['Name']  # Ambil nama dari form

        input_data = [
            int(request.form['Gender']),
            float(request.form['Age']),
            int(request.form['City']),
            int(request.form['WorkingStatus']),
            int(request.form['Profession']),
            float(request.form['AcademicPressure']),
            float(request.form['WorkPressure']),
            float(request.form['StudySatisfaction']),
            float(request.form['JobSatisfaction']),
            int(request.form['DietaryHabits']),
            int(request.form['Degree']),
            int(request.form['SuicidalThoughts']),
            float(request.form['WorkHours']),
            float(request.form['FinancialStress']),
            int(request.form['FamilyHistory']),
            float(request.form['SleepDuration'])
        ]

        input_scaled = scaler.transform([input_data])
        prediction = model.predict(input_scaled)[0]

        result = 'Depressed' if prediction == 1 else 'Not Depressed'
        return render_template('index.html', prediction_text=f'{name}, your result: {result}')
    except Exception as e:
        return f'Error: {str(e)}'

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)
